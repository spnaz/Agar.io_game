package ir.agar.Model.Objects;

public enum Authority {
    SPLIT_USER, SPLIT_GEAR, COMBINE, EAT, EATEN;
}
