package ir.agar.Model;

import ir.agar.Game;
import ir.agar.Model.Objects.*;
import ir.agar.Game;

import java.awt.*;
import java.util.*;
import java.util.List;

public class ServerEngine extends Thread implements GameEngine {
    public static final int PLAYER_CIRCLE_RADIUS = 30;
    public static final int PLAYER_CIRCLE_MIN_RADIUS = 20;
    public static final int PLAYER_CIRCLE_CENTER_ALIGN = 80;
    public static final int SPEED = 3;
    public static final int MAX_GEARS = 4;
    public static final int GEAR_MAX_RADIUS = 60;
    public static final int GEAR_MIN_RADIUS = 25;

    public static final Random random = new Random();

    private boolean isUpdated = true;

    private int waitUntilNextGear = (int) (random.nextInt() % (1000 / Game.GAME_SLEEP));

    public int remainingEnergyCircles;

    private int mouseX = 0, mouseY = 0;

    private static ServerEngine currentInstance;
    private Timer createEnergyCirclesTimer;

    private Object lockObject = new Object();

    private Map<String, Player> players = Collections.synchronizedMap(new Hashtable<>());

    private Map<String, String> passwords = Collections.synchronizedMap(new Hashtable<>());

    private Map<String, Player> registeredPlayers = Collections.synchronizedMap(new Hashtable<>());
    private List<PlayerCircle> playerCircles = Collections.synchronizedList(new ArrayList<>());
    private List<PowerCircle> powerCircles = Collections.synchronizedList(new ArrayList<>());
    private List<GearCircle> gearCircles = Collections.synchronizedList(new ArrayList<>());
    private List<EnergyCircle> energyCircles = Collections.synchronizedList(new ArrayList<>());

    public ServerEngine(int energyCircleCount) {

        this.currentInstance = this;
        createEnergyCirclesTimer();
        this.remainingEnergyCircles = energyCircleCount;
    }

    @Override
    public void run() {
        while (true) {
            synchronized (this) {
                update();
            }
            isUpdated = true;

            try {
                sleep(Game.GAME_SLEEP * 3 / 4 + 1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public Player registerPlayer(String username, String password, String name, Color color) {
        if (registeredPlayers.containsKey(username))
            return null;

        Player player = new Player(username, name, color, null);

        passwords.put(username, password);

        registeredPlayers.put(username, player);

        return player;
    }

    public void addPlayerToGame(String username) {
        Player player = getPlayer(username);
        player.reset();

        players.put(player.getUsername(), player);
    }

    public boolean addPlayerToGame(String username, String password) {
        if (!checkLogin(username, password))
            return false;


        Player player = registeredPlayers.get(username);
        player.reset();

        players.put(player.getUsername(), player);

        return true;
    }

    private void createEnergyCirclesTimer() {
        createEnergyCirclesTimer = new Timer();
        createEnergyCirclesTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                ServerEngine.getCurrentInstance().createEnergyCircles();
            }
        }, Game.RANDOM_POINTS_CREATION_PREIOD, Game.RANDOM_POINTS_CREATION_PREIOD);
    }

    private void createEnergyCircles() {
        if (remainingEnergyCircles < 1)
            return;

        for (int i = 0; i < Game.RANDOM_POINTS_PER_PERIOD && remainingEnergyCircles > 0; i++) {

            int x = (int) (Math.random() * Game.width);
            int y = (int) (Math.random() * Game.height);
            int color = (int) (Math.random() * 0xffffff);

            EnergyCircle energyCircle = new EnergyCircle(x, y, new Color(color));

            energyCircles.add(energyCircle);

            remainingEnergyCircles--;
        }
    }

    public ServerEngine() {
        this(Game.RANDOM_POINTS_COUNT);
    }

    @Override
    public List<PowerCircle> getPowerCircles() {
        return powerCircles;
    }

    @Override
    public List<PlayerCircle> getPlayerCircles() {
        return playerCircles;
    }

    public static ServerEngine getCurrentInstance() {
        return currentInstance;
    }


    public void setMouseLocation(int x, int y, Player player) {
        List<PlayerCircle> playerCircles = player.getPlayerCircles();
        if (playerCircles.size() == 0)
            return;


        long centerX = 0, centerY = 0;
        for (int i = 0; i < playerCircles.size(); i++) {
            centerX += playerCircles.get(i).getX();
            centerY += playerCircles.get(i).getY();
        }

        centerX /= playerCircles.size();
        centerY /= playerCircles.size();

        int vx = (int) (x - centerX);
        int vy = (int) (y - centerY);

        if (Math.abs(vx) + Math.abs(vy) < 5)
            player.setDirection(Direction.STATIC);
        else
            player.setDirection(Direction.getDirectionByVector(vx, vy));
    }

    public void update() {
        updateGears();
        updateCirclesPosition();
        updatePowers();
        splitCirclesByGear();
        checkPlayersCircles();
        checkEnergyCircles();
        checkPowerCircles();
    }

    private void checkPowerCircles() {
        ArrayList<PowerCircle> powerCirclesToDelete = new ArrayList<>();
        synchronized (playerCircles) {
            for (PlayerCircle playerCircle : playerCircles) {
                synchronized (powerCircles) {
                    for (PowerCircle powerCircle : powerCircles) {
                        if (playerCircle.contains(powerCircle)) {
                            powerCirclesToDelete.add(powerCircle);
                            playerCircle.getPlayer().addPowerCircle(powerCircle);
                            break;
                        }
                    }
                }
            }
        }
        powerCircles.removeAll(powerCirclesToDelete);

    }

    private void updatePowers() {
        ArrayList<PowerCircle> powerCirclesToDelete = new ArrayList<>();
        if (Math.random() <= 0.01 && powerCircles.size() < 3) {
            PowerType[] powerTypes = PowerType.values();
            PowerType powerType = powerTypes[(int) (Math.random() * powerTypes.length)];

            int x = (int) (Math.random() * Game.width);
            int y = (int) (Math.random() * Game.height);

            PowerCircle powerCircle = new PowerCircle(x, y, powerType);

            powerCircles.add(powerCircle);

        }

        synchronized (powerCircles) {
            for (PowerCircle powerCircle : powerCircles) {
                if (!powerCircle.isAlive())
                    powerCirclesToDelete.add(powerCircle);
                powerCircle.update();
            }
        }

        powerCircles.removeAll(powerCirclesToDelete);
    }

    private void splitCirclesByGear() {
        ArrayList<PlayerCircle> newPlayerCircles = new ArrayList<>();
        synchronized (gearCircles) {
            for (GearCircle gear : gearCircles) {
                PlayerCircles:
                for (PlayerCircle playerCircle : playerCircles) {
                    if (playerCircle.contains(gear)) {
                        playerCircle.getPlayer().split();
                        break PlayerCircles;
                    }
                }
            }
        }
    }

    private void updateGears() {
        if (gearCircles.size() < MAX_GEARS && (waitUntilNextGear--) < 1) {
            waitUntilNextGear = 50 + random.nextInt() % 500;
            createGearCircle();
        }

        ArrayList<GearCircle> destroyedGearCircles = new ArrayList<>();

        synchronized (gearCircles) {
            for (GearCircle gearCircle : this.gearCircles) {
                gearCircle.updateAnimation();

                if (gearCircle.isDestroyed()) {
                    destroyedGearCircles.add(gearCircle);
                }
            }

        }
        gearCircles.removeAll(destroyedGearCircles);
    }

    private void createGearCircle() {
        int x = (int) (Math.random() * Game.width);
        int y = (int) (Math.random() * Game.height);
        double radius = GEAR_MIN_RADIUS + Math.random() * (GEAR_MAX_RADIUS - GEAR_MIN_RADIUS);
        synchronized (gearCircles) {
            for (GearCircle gearCircle : gearCircles) {
                if (gearCircle.contains(x, y, radius)) {
                    createGearCircle();
                    return;
                }
            }
        }

        int color = 0x666666;


        GearCircle gearCircle = new GearCircle(x, y, new Color(color), radius);

        gearCircles.add(gearCircle);
    }

    private void checkEnergyCircles() {
        synchronized (playerCircles) {
            for (int i = 0; i < playerCircles.size(); i++) {
                PlayerCircle playerCircle = playerCircles.get(i);
                synchronized (energyCircles) {
                    for (int j = 0; j < energyCircles.size(); j++) {
                        EnergyCircle energyCircle = energyCircles.get(j);
                        if (playerCircle.getArea() > energyCircle.getArea() && playerCircle.contains(energyCircle)) {
                            playerCircle.addCircle(energyCircle);
                            energyCircles.remove(energyCircle);
                            j--;
                        }
                    }
                }
            }
        }
    }


    private void checkPlayersCircles() {
        synchronized (playerCircles) {
            for (PlayerCircle biggerCircle : playerCircles) {
                if (biggerCircle.isDisabled())
                    continue;

                for (PlayerCircle smallerCircle : playerCircles) {
                    if (smallerCircle.isDisabled() || biggerCircle.getRadius() < smallerCircle.getRadius() || smallerCircle.getPlayer().isGodMode())
                        continue;

                    if (biggerCircle.contains(smallerCircle)) {
                        biggerCircle.addCircle(smallerCircle);
                        smallerCircle.setDisabled(true);
                    }
                }
            }

            for (int i = 0; i < playerCircles.size(); i++) {
                if (playerCircles.get(i).isDisabled())
                    playerCircles.remove(i--);
            }
        }
    }

    private void updateCirclesPosition() {
        synchronized (playerCircles) {
            for (PlayerCircle playerCircle : playerCircles) {
                Direction direction = playerCircle.getPlayer().getDirection();
                double x = playerCircle.getX();
                double y = playerCircle.getY();
                playerCircle.setX(direction.moveX(x, SPEED * playerCircle.getPlayer().getSpeedRatio()));
                playerCircle.setY(direction.moveY(y, SPEED * playerCircle.getPlayer().getSpeedRatio()));
            }
        }
    }

    public void splitPlayer(int playerNumber) {
        players.get(playerNumber).split();
    }


    public Player getPlayer(String username) {
        return players.getOrDefault(username, null);
    }

    @Override
    public synchronized boolean isUpdated() {
        if (isUpdated) {
            this.isUpdated = false;
            return true;
        }
        return false;
    }

    @Override
    public Map<String, Player> getPlayers() {
        return players;
    }

    @Override
    public List<GearCircle> getGearCircles() {
        return gearCircles;
    }

    @Override
    public List<EnergyCircle> getEnergyCircles() {
        return energyCircles;
    }

    public boolean checkLogin(String username, String password) {
        System.out.println(username);
        System.out.println(password);
        if (passwords.containsKey(username) &&
                passwords.get(username).equals(password))
            return true;
        return false;
    }
}
